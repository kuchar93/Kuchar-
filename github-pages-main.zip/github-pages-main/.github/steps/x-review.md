## Review

_Congratulations, you've completed this exercise and learned a lot about GitHub Pages and Jekyll!_

<img src="https://octodex.github.com/images/constructocat2.jpg" alt="celebrate" width=300 align=right>

Here's a recap of your accomplishments:

- You enabled GitHub Pages.
- You selected a theme using the config file.
- You learned about proper directory format and file naming conventions in Jekyll.
- You created your first blog post with Jekyll and GitHub Pages!

### What's next?

- Keep working on your GitHub Pages site... we love seeing what you come up with!
- [Take another GitHub Skills exercise](https://skills.github.com/).
- [Read the GitHub Pages docs](https://docs.github.com/en/pages).
